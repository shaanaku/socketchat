var Usermodel = require('../model/createUser');
var nodemailer = require('nodemailer');


var transporter = nodemailer.createTransport('smtps://rohansunpreet@gmail.com:mangalsing@smtp.gmail.com');

module.exports.verify = function(req,res, success, error) {
       var confirmation = req.params.confirmation;
        Usermodel.findOneAndUpdate(confirmation,
                { $set: { status: 1 } },
                response(success, error));
};

module.exports.signup = function(req,res){
  var user = new Usermodel();
  user.username = req.body.email;
  var e = req.body.email;
  user.email = req.body.username;
  user.password = user.generateHash(req.body.password);
  user.gender = req.body.gender;
  user.status = 0 ;
  user.confirmation = makeid();
  console.log(req.body);
  console.log(user.confirmation);
  
  Usermodel.findOne({email:req.body.email},function(err,person){
  	if(err){
  		console.log(err,'error');
  	}else{
  		if(!person){
  			user.save(function (err,data){
  				if(err){
  					res.send(err);
  				}else{
            var url ="http://localhost:3000/users/email-verification/" + user.confirmation   ;
console.log(url);
            var mailOptions = {
    from: "Sunpreet App", // sender address 
    to: 'c.vicky1231990@gmail.com', // list of receivers 
     subject: 'Confirm your account', // Subject line 
    html: '<p>Please verify your account by clicking <a href='+url+'>this link</a>.</p>' 
   
};
 
// send mail with defined transport object 
transporter.sendMail(mailOptions, function(error, info){
    if(error){
        return console.log(error);
    }
    console.log('Message sent: ' + info.response);
});
  					res.send(data);
            //console.log(data);
  				}
  			})
  		}else{
  			res.send({error:'email is already registered'});
  		}
  	}
  })
}


function makeid()
{
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    for( var i=0; i < 5; i++ )
        text += possible.charAt(Math.floor(Math.random() * possible.length));

    return text;
}

