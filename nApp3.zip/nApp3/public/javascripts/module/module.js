// main controller and routing in anfularjs in defined herre
 var app = angular.module('myApp',['ngRoute','ngMessages','myApp.directives']);

app.config(['$routeProvider','$locationProvider',function($routeProvider,$locationProvider){
$routeProvider.when('/login',{
    
    templateUrl: 'javascripts/view/login.html',
    controller:'loginController'
})
.when('/signup',{
    
    templateUrl: 'javascripts/view/signup.html',
    controller:'loginController',
})
.when('/email-verification/:confirmation',{
    
    templateUrl: 'javascripts/view/verify.html',
    controller:'loginController',
})
.otherwise({
    redirectTo:'/login'

});
$locationProvider.html5Mode({
      enabled: true,
     requireBase: false
      });
}]);


var app = angular.module('myApp.directives', ['ngMessages'])
 app.directive('compareTo', [function() {
    return {
        require: "ngModel",
        scope: {
            otherModelValue: "=compareTo"
        },
        link: function(scope, element, attributes, ngModel) {
             
            ngModel.$validators.compareTo = function(modelValue) {
                return modelValue == scope.otherModelValue;
            };
 
            scope.$watch("otherModelValue", function() {
                ngModel.$validate();
            });
        }
    };
}]); 

app.directive('fileModel', ['$parse', function ($parse) {
return {
    restrict: 'A',
    link: function(scope, element, attrs) {
        var model = $parse(attrs.fileModel);
        var modelSetter = model.assign;

        element.bind('change', function(){
            scope.$apply(function(){
                modelSetter(scope, element[0].files[0]);
            });
        });
    }
};
}]);