var express = require('express');
var router = express.Router();
var usermodel = require('../model/usermodel');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

/*router.get('/', function(req, res, next) {
  res.render('signup', { title: 'Express' });
});*/

router.get('/signup', function(req, res, next) {
  res.render('signup', { title: 'Express' });
});

router.get('/signin', function(req, res, next) {
  res.render('signin', { title: 'Express' });
});

router.get('/google', function(req, res, next) {
  res.render('google', { title: 'Express' });
});

router.get('/github', function(req, res, next){
	res.render('github',{title : 'Express'});
});


module.exports = router;
