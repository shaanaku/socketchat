var passport = require('passport');
var LocalStrategy = require('passport-local').Strategy;
var GoogleStrategy = require('passport-google-oauth').OAuth2Strategy;
var GitHubStrategy = require('passport-github').Strategy;
var User = require('../app/models/user');

module.exports = function(passport)
{
	passport.serializeUser(function(user, done){
		done(null, user.id);
	});
	
	passport.deserializeUser(function(id, done){
		User.findById(id, function(err, user){
			done(err, user);
		});
	});
	
	passport.use('local-signup', new LocalStrategy({
		usernameField : 'email',
		passwordField : 'password',
		passReqToCallback : true
	},function(req, email, password, done){
		process.nextTick(function(){
			User.findOne({'local.email' : email},function(err, user){
				if(err)
					return done(err);
				if(user){
					return done(null, false, req.flash('signupMessage', 'That email is already taken.'));
				}
				else{
					var newUser = new User();
					newUser.local.email = email;
					newUser.local.password = newUser.generateHash(password);
					
					newUser.save(function(err){
						if(err)
							throw err;
						return done(null, newUser);
					});
				}
			});
		});
	}));
		
		passport.use('local-login', new LocalStrategy({
			usernameField : "email",
			passwordField : "password",
			passReqToCallback : true
		},function(req, email, password, done){
			User.findOne({'local.email' : email}, function(err, user){
				
				if(err)
					return done(err);
				if(!user)
					return done(null, false, req.flash('loginMessage', 'No user found'));
				if(!user.validPassword(password))
				return done(null, false, req.flash('loginMessage','Oops! Wrong password'));
			return done(null, user);
			});
		}));
	
	
	 passport.use(new GoogleStrategy({

        clientID        : '283858339447-nmo9b6qpc4pfs0o27b1runsajqp76bi5.apps.googleusercontent.com',
        clientSecret    : 'MUR31OkbwuJyW9SuTRO1u2Fl',
        callbackURL     : '/auth/google/callback',
		//passReqToCallback: true
    },
    function(token, refreshToken, profile, done) {
        
        process.nextTick(function() {
           
            User.findOne({ 'google.id' : profile.id }, function(err, user) {
                if (err)
                    return done(err);

                if (user) {
                   
                    return done(null, user);
                } else {
                    var newUser = new User();

                    newUser.google.id    = profile.id;
                    newUser.google.token = token;
                    newUser.google.name  = profile.displayName;
                    newUser.google.email = profile.emails[0].value; // pull the first email
                 
                    newUser.save(function(err) {
                        if (err)
                            throw err;
                        return done(null, newUser);
                    });
                }
            });
        });

    }));
	
	
	
	/*passport.use(new GitHubStrategy({
    clientID: '3ff6adde71ff0f352118',
    clientSecret: '5f0de562878b431b8cbf13f566ce5ada1d0d7473',
    callbackURL: "/auth/github/callback"
  },	
	function(accessToken, refreshToken, profile, done) {
        
        process.nextTick(function() {
           
            User.findOne({ 'githubId.id' : profile.id }, function(err, user) {
                if (err)
                    return done(err);

                if (user) {
                   
                    return done(null, user);
                } else {
                    var newUser = new User();

                    newUser.google.id    = profile.id;
                    newUser.google.token = token;
                    newUser.google.name  = profile.displayName;
                    newUser.google.email = profile.emails[0].value; // pull the first email
                 
                    newUser.save(function(err) {
                        if (err)
                            throw err;
                        return done(null, newUser);
                    });
                }
            });
        });

    }));*/
	passport.use(new GitHubStrategy({
    clientID: '3ff6adde71ff0f352118',
    clientSecret: '5f0de562878b431b8cbf13f566ce5ada1d0d7473',
    callbackURL: "/auth/github/callback"
  },
  function(accessToken, refreshToken, profile, cb) {
    User.findOne({ githubId: profile.id }, function (err, user) {
      return cb(err, user);
    });
  }
));
	
};
            
  
 

 



