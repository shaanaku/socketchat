module.exports = function(app, passport)
{
	app.get('/', function(req, res){
		res.render('index');
	});
	
	app.get('/signin', function(req, res){
		res.render('signin',{message: req.flash('loginMessage')});
	});
	
	app.post('/signin', passport.authenticate('local-login', {
		successRedirect : '/profile',
		failureRedirect : '/signin',
		failureFlash    : true
	}));
	
	app.get('/signup', function(app, passport){
		res.render('signup',{message : req.flash('signupMessage')});
	});
	
	app.post('/signup', passport.authenticate('local-signup',{
		successRedirect : '/profile',
		failureRedirect : '/signup',
		failureFlash : true
	}));
	
	app.get('/profile', isLoggedIn, function(req, res){
		res.render('profile',{
			user : req.user
		});
	});
	
	app.get('/profiles', isLoggedIn, function(req, res){
		res.render('profiles',{
			user : req.user
		});
	});
	
	app.get('/auth/google', passport.authenticate('google', { scope : ['profile', 'email'] }));

    // the callback after google has authenticated the user
    app.get('/auth/google/callback',
            passport.authenticate('google', {
                    successRedirect : '/profiles',
                    failureRedirect : '/google',
					failureFlash : true
            }));
			
	
	app.get('/auth/github', passport.authenticate('github'));
	
	app.get('/auth/github/callback',
	passport.authenticate('github',{
		successRedirect : '/profiles',
		failureRedirect : 'github',
		failureFlash : true
	}))
	/*app.get('/google', function(req, response){
		res.render('google',{message : req.flash('googleMessage')});
	});
	
	app.post('/google', passport.authenticate('google',{
		successRedirect : '/profile',
		failureRedirect : '/google',
		failureFlash : true
	}));*/
	
	
	app.get('/logout', function(req, res){
		req.logout();
		res.redirect('/');
	});
};
 function isLoggedIn(req, res, next){
	 if(req.isAuthenticated())
		 return next();
	 res.redirect('/');
 }


 
 
 
 
 
 