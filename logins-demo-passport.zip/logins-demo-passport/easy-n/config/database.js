module.exports ={

'url' : "mongodb://akshma:akshma@ds013901.mlab.com:13901/authentication123"

};