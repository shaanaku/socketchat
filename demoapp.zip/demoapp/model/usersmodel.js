var mongoose = require("mongoose");

var Schema = mongoose.Schema;

var userSchema = new Schema({
	username: String,
	lname :  String,
	email : {type: String, required: true, unique: true},
	password : {type: String, required: true},
	phone : {type: Number, required: true},
	address : {type: String, required: true},
	gender : {type: String, required: true},
	qualification : {type: String, required: true},
	hobbies: String
});


/*userSchema.methods.toJSON = function()
{
	var obj = this.toObject()
	delete obj.password
	return obj	
}*/

var User = mongoose.model('User', userSchema);
module.exports = User;


























