var express = require('express');
var router = express.Router();
var usermodel = require("../model/usersmodel");
var auth = require("./auth");

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('signup', { title: 'Express' });
});

router.get('/signup', function(req, res, next) {
  res.render('signup', { title: 'Express' });
});

router.get('/signin', function(req, res, next) {
  res.render('signin', { title: 'Express' });
});
router.get('/details',auth.auth, function(req, res, next) {
  
  
			 res.render('details', { user: req.session.user });
		  
});


router.get('/viewuser', function(req, res, next) {
  
  usermodel.find({},function(err,users)
	  {
		  if(err)
		  {
			  res.send("err", err);
		  }
		  else
		  {
			 //res.send(users);
			  res.render('viewuser', {user :users});
			 //res.render('details', { user: req.session.user });
		  }
	  });
});

router.post('/signup', function(req, res) {
	
	console.log(req.param);
 		
    var user = new usermodel();
    user.username = req.body.username;
    user.lname = req.body.lname;
    user.email = req.body.email;
    user.password = req.body.password;
	user.phone = req.body.phone;
	user.address = req.body.address;
	user.gender = req.body.gender;
	user.qualification = req.body.qualification;
	user.hobbies = req.body.hobbies;
	//user.hobbies = JSON.stringify(req.body.hobbies);
   usermodel.findOne({email:req.body.email},function(err, data)
	   {
		   if(err)
		   {
			   console.log("err", err);
		   }
		   else{
			   if(!data)
			   {
				   
				   user.save(function(err, data)
				   {
					   if(err)
					   {
						   res.send(err);
					   }
					   else{
						  res.send(data);
					   }
				   });
			   }
			   else{
				   res.send({error:"Email is already registered"});
			   }
			   
		   }
	   });
	
});

router.post('/signin', function(req, res, next) {
	console.log(req.param);
	//res.send(req.body);
	var email = req.body.username
	usermodel.findOne({email:req.body.username}, function(err, data){
		if(err)
		{
			console.log("err", err);
		}
		else{
			
			if(data)
			{
				if(data.password !== req.body.password)
				{
					res.send({err:"not a valid user"});
				}
			else{
				//res.send({error:"Password not matched"});
				req.session.user = data;
				res.redirect('/details');
			}
			
			}
			else{
				res.send({error:"Email is not registered"});
			}
		}
		
	});
  //res.render('signin', { title: 'Express' });
});

router.get('/logout', function(req, res, next) {
 req.session.destroy(function(err) {
  //res.send('Session deleted');
  res.redirect('/signup');
});
});




router.get('/delete/:id', function(req, res, next) {
	var uid = req.params.id;
 usermodel.findByIdAndRemove(uid, function(err, data){
	 	 if(err)
		 {
			 console.log("error", err);
		 }
		 else 
		 {
			 //console.log({data:"user deleted"});
			 res.redirect('/viewuser');
		 }
		 //res.send('hi');
		 //res.redirect('/viewuser');
	
 });
});

router.get('/edit/:id', function(req, res, next) {
	var uid = req.params.id;
	usermodel.findById(uid, function(err, docs)
	{
		res.render('edit', { user: docs });
	});
  
});

router.post('/edit/:id', function(req, res, next)
{
	console.log(req.param);
	var uid = req.params.id;
		usermodel.findById(uid, function(err, users){
	users.username = req.body.username;
	users.lname = req.body.lname;
	users.phone = req.body.phone;
	users.address = req.body.address;
	users.password = req.body.password;
	users.gender = req.body.gender;
	users.qualification = req.body.qualification;
	users.hobbies = req.body.hobbies;
	//users.hobbies = JSON.stringify(req.body.hobbies);
	
	users.save(function(err, data)
	{
		if(err)
		{
			res.send(err);
		}
		else
		{
			res.redirect('/viewuser');
			//res.send(data);
		}
	});
	
});
});

/*router.get('/edit:id', function(req, res, next) {
  res.render('edit', { title: 'Express' });
});

router.put('/edit/:id', function(req, res, next) {
 Setting.findAndModify(req.params.id,req.body, function (err, post)  {
 if (err)
 {	 return next(err);
 }
 else{
	 res.redirect('/signup');
 }
  //user:res.json(post);
 });*/

/*router.get('/edit/:id', function(req,res, next)
{
	var uid = req.params.id;
	usermodel.findById(uid, function(err, docs){
		res.render('edit',{data:docs});
		
		usermodel.update({ "_id.username": "32de3", "_id.uid": "56f933b4395653500d60461b", "_id.lname":"3edf","password":"df", "email":"3er3er3r" },function(err, data){
			if(err)
			{
				console.log("error",err);
			}
			else{
				console.log({data: "updated successfully"});
			}
			
		});
		
	});
});*/


module.exports = router;




