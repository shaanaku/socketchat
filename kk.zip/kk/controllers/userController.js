var Usermodel = require('../model/userModel');


module.exports.signup = function(req,res){
  var user = new Usermodel();
  user.username = req.body.email;
  user.email = req.body.username;
  user.password = user.generateHash(req.body.password);
  user.myFile = req.file.filename;
  user.gender = req.body.gender;

  Usermodel.findOne({email:req.body.email},function(err,person){
  	if(err){
  		console.log(err,'error');
  	}else{
  		if(!person){
  			user.save(function (err,data){
  				if(err){
  					res.send(err);
  				}else{
  					res.send(data);
  				}
  			})
  		}else{
  			res.send({error:'email is already registered'});
  		}
  	}
  })
}