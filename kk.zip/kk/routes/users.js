var express = require('express');
bodyParser = require('body-parser'),
 router = express.Router();
var mime= require('mime-types');
var multer = require('multer');
  mongoose = require('mongoose'),
  bcrypt = require('bcryptjs'),
//var app = express();
 passport = require('passport');



var LocalStrategy = require('passport-local').Strategy;

var User = require('../model/userModel.js');


    var session = require('express-session');
/* GET users listing. */
nev = require('../index.js')(mongoose);

// sync version of hashing function
var myHasher = function(password, tempUserData, insertTempUser, callback) {
  var hash = bcrypt.hashSync(password, bcrypt.genSaltSync(8), null);
  return insertTempUser(hash, tempUserData, callback);
};

// async version of hashing function
myHasher = function(password, tempUserData, insertTempUser, callback) {
  bcrypt.genSalt(8, function(err, salt) {
    bcrypt.hash(password, salt, function(err, hash) {
      return insertTempUser(hash, tempUserData, callback);
    });
  });
};

// NEV configuration =====================
nev.configure({
  persistentUserModel: User,
  expirationTime: 600, // 10 minutes

  verificationURL: 'http://localhost:3000/email-verification/${URL}',
  transportOptions: {
    service: 'Gmail',
    auth: {
      user: 'kamalkishore273@gmail.com',
      pass: '98167kishore'
    }
  },

  hashingFunction: myHasher,
  passwordFieldName: 'pw',
}, function(err, options) {
  if (err) {
    console.log(err);
    return;
  }

  console.log('configured: ' + (typeof options === 'object'));
});

nev.generateTempUserModel(User, function(err, tempUserModel) {
  if (err) {
    console.log(err);
    return;
  }

  console.log('generated temp user model: ' + (typeof tempUserModel === 'function'));
});


// Express stuff =========================
router.use(bodyParser.urlencoded());
router.get('/', function(req, res) {
  res.sendFile('index.html', {
    root: __dirname
  });
});

router.post('/signup', function(req, res) {
  var email = req.body.username;
  console.log(req.body.username);
  // register button was clicked
  if (req.body.type === 'register') {
    var password = req.body.password;
    var newUser = new User({
      email: email,
      password: password
    });

    nev.createTempUser(newUser, function(err, newTempUser) {
      if (err) {
        return res.status(404).send('ERROR: creating temp user FAILED');
      }

      // new user created
      if (newTempUser) {
        var URL = newTempUser[nev.options.URLFieldName];

        nev.sendVerificationEmail(email, URL, function(err, info) {
          if (err) {
            return res.status(404).send('ERROR: sending verification email FAILED');
          }
          res.json({
            msg: 'An email has been sent to you. Please check it to verify your account.',
            info: info
          });
        });

      // user already exists in temporary collection!
      } else {
        res.json({
          msg: 'You have already signed up. Please check your email to verify your account.'
        });
      }
    });

  // resend verification button was clicked
  } else {
    nev.resendVerificationEmail(email, function(err, userFound) {
      if (err) {
        return res.status(404).send('ERROR: resending verification email FAILED');
      }
      if (userFound) {
        res.json({
          msg: 'An email has been sent to you, yet again. Please check it to verify your account.'
        });
      } else {
        res.json({
          msg: 'Your verification code has expired. Please sign up again.'
        });
      }
    });
  }
});


// user accesses the link that is sent
router.get('/email-verification/:URL', function(req, res) {
  var url = req.params.URL;

  nev.confirmTempUser(url, function(err, user) {
    if (user) {
      nev.sendConfirmationEmail(user.email, function(err, info) {
        if (err) {
          return res.status(404).send('ERROR: sending confirmation email FAILED');
        }
        res.json({
          msg: 'CONFIRMED!',
          info: info
        });
      });
    } else {
      return res.status(404).send('ERROR: confirming temp user FAILED');
    }
  });
});













 passport.use(new LocalStrategy(function(username, password, done) {
        User.findOne({username: username }, function(err, user) {
          if (err) { return done(err,'sun'); }
          if (!user) {
            return done(null, false, { message: 'Incorrect username.' });
          }
          if (!user.validPassword(password)) {
            return done(null, false, { message: 'Incorrect password.' });
          }
          return done(null, user);
         // console.log(user)
        });
      }));

    //passport serialize user for their session
    passport.serializeUser(function(user, done) {
      done(null, user.id);
    });
    //passport deserialize user 
    passport.deserializeUser(function(id, done) {
      user.findById(id, function(err, user) {
        done(err, user);
      });
    });


    function isAuthenticated(req,res,next){
        if(req.isAuthenticated())return next();
         res.redirect('/');
    }


var userStorage = multer.diskStorage({
	destination: function(req,file,cb){
		cb(null,'./public/uploads/')
	},
	filename: function(req,file,cb){
		console.log(file,'file');
		cb(null,Date.now()+'.'+mime.extension(file.mimetype));
	}
});
var userUpload = multer({storage: userStorage});




var BlogStorage = multer.diskStorage({
	destination: function(req,file,cb){
		cb(null,'./public/blogUpload/')
	},
	filename: function(req,file,cb){
		console.log(file,'file');
		cb(null,Date.now()+'.'+mime.extension(file.mimetype));
	}
})


//------------------------------------

var blogUpload = multer({storage: BlogStorage});

/* GET users listing. */
var userController = require('../controllers/userController');

//var passport = require('../controllers/passport')(passport); 


// routes 
//router.get('/profile',userController.getProfile);

//router.post('/signup',userUpload.single('file'),userController.signup);

router.post('/login',passport.authenticate('local'),function(req,res){

 res.send(req.user);
console.log(req.user);
});



router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

module.exports = router;
